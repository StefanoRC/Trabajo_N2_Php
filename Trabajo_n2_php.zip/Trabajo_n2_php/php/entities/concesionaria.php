    <?php

    require_once "../entities/I_concesionaria.php";

    abstract class Concesionaria implements I_Concesionaria
    {
        public $vehiculos = [];

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function resultadoTp2()
        {
            $c = new Vehiculo();
            $c->nuevosVehiculos();
            $c->listaVehiculos();

            echo "<br>=============================" . "<br>";

            $c->vehiculoMasCaro();
            $c->vehiculoMasBarato() . "<br>";
            $c->vehiculoConY();

            echo "<br><br>=============================" . "<br>";

            $c->precioMayorMenor();

            echo "<br>=============================" . "<br>";

            $c->ordenNatural();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function __getAtributos($property)
        {
            if (property_exists($this, $property)) {
                return $this->$property;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function nuevosVehiculos()
        {
            $this->vehiculos[] = new Auto("Peugot", 206, 4, 200000);
            $this->vehiculos[] = new Moto("Honda", "Titan", 125, 60000);
            $this->vehiculos[] = new Auto("Peugot", 208, 5, 250000);
            $this->vehiculos[] = new Moto("Yamaha", "YBR", 160, 80500);
        }


        public function listaVehiculos()
        {
            foreach ($this->vehiculos as $vehiculo) {
                echo $vehiculo . "<br>";
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function vehiculoMasCaro()
        {
            $precioMasCaro = 0;
            $vehiculoMasCaro = "";

            foreach ($this->vehiculos as $vehiculo) {
                $precio = $vehiculo->__getAtributos('precio');

                if ($precio > $precioMasCaro) {
                    $precioMasCaro = $precio;
                    $vehiculoMasCaro = $vehiculo;
                }
            }
            echo  "<br>Vehículo más caro: " . $vehiculoMasCaro->__getAtributos('marca') . " " . $vehiculoMasCaro->__getAtributos('modelo');
        }


        public function vehiculoMasBarato()
        {
            $precioMasBarato = 10000000000000;
            $vehiculoMasBarato = "";
            foreach ($this->vehiculos as $vehiculo) {
                $precio = $vehiculo->__getAtributos('precio');
                if ($precio < $precioMasBarato) {
                    $precioMasBarato = $precio;
                    $vehiculoMasBarato = $vehiculo;
                }
            }
            echo "<br>Vehículo más barato: " . $vehiculoMasBarato->__getAtributos('marca') . " " . $vehiculoMasBarato->__getAtributos('modelo');
        }

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function vehiculoConY()
        {
            foreach ($this->vehiculos as $v) {
                $modelo = $v->__getAtributos('modelo');
                $marca = $v->__getAtributos('marca');
                $precio = $v->__getAtributos('precio');
                if ($v->__getAtributos('modelo') == "Y") {
                    $modelo = $v;
                    $marca = $v;
                    $precio = $v;
                }
            }
            echo "<br>Vehículo que contiene en el modelo la letra ‘Y’: " .  $marca . " " . $modelo . " $" . $precio;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////

        public function precioMayorMenor()
        {
            usort($this->vehiculos, function ($a, $b) {
                return $b->precio - $a->precio;
            });

            echo "<br>Vehículos ordenados por precio de mayor a menor:<br>";
            foreach ($this->vehiculos as $vehiculo) {
                echo   $vehiculo->marca . " " . $vehiculo->modelo . "<br>";
            }
        }


        public function ordenNatural()
        {
            usort($this->vehiculos, function ($a, $b) {
                return strcmp($a, $b);
            });
            echo "<br>Vehículos ordenados por orden natural (marca, modelo, precio):";
            foreach ($this->vehiculos as $vehiculo) {
                echo  "<br>" . $vehiculo;
            }
        }
    }
