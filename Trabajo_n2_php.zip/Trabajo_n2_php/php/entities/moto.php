<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";

class Moto extends Vehiculo
{

    public $cilindrada;


    public function __construct($marca = "", $modelo = "", $cilindrada = 0, $precio = 0)
    {
        parent::__construct($marca, $modelo, $precio);
        $this->cilindrada = $cilindrada;
    }


    public function __toString(): string
    {
        return parent::__tostring() . " // Cilindrada: " . $this->cilindrada . "c" . " // Precio: $" . $this->precio;
    }
}
