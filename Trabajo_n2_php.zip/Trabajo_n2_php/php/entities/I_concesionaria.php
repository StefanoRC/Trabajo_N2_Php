<?php
interface I_Concesionaria
{
    public function listaVehiculos();

    public function vehiculoMasCaro();

    public function vehiculoMasBarato();

    public function vehiculoConY();

    public function precioMayorMenor();

    public function ordenNatural();
}
