<?php
class Vehiculo extends Concesionaria
{
    public $marca;
    public $modelo;
    public $precio;


    public function __toString(): string
    {
        return  "Marca: "   . $this->marca . " // Modelo: " . $this->modelo;
    }


    public function __construct(string $marca = "", $modelo = "", int $precio = 0)
    {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
    }
}
