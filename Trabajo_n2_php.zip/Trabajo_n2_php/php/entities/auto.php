    <?php
    require_once "../entities/concesionaria.php";
    require_once "../entities/vehiculo.php";

    class Auto extends Vehiculo
    {

        public $puertas;


        public function __construct($marca = "", $modelo = "", $puertas = 0, $precio = null)
        {
            parent::__construct($marca, $modelo, $precio);
            $this->puertas = $puertas;
        }


        public function __toString(): string
        {
            return parent::__toString() . " // Puertas: " . $this->puertas . " // Precio: $" . $this->precio;
        }
    }
