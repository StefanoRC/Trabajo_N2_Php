<?php

require_once "../entities/I_concesionaria.php";
require_once "../entities/concesionaria.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";
require_once "../entities/vehiculo.php";

$c = new Vehiculo();
$c->resultadoTp2();









